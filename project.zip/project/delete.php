<?php
$id=$_POST['pk1'];
echo $id;
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Online Shopping";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "DELETE FROM Product WHERE ID='$id' ";
if (mysqli_query($conn, $sql)) {
    header('Location: '."./amin.php");

} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
mysqli_close($conn);


?>