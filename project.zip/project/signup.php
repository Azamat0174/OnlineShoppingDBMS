<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Online Shopping";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


//3. If the form is submitted or not.
//3.1 If the form is submitted
if (isset($_POST['email']) and isset($_POST['password'])){
//3.1.1 Assigning posted values to variables.
$username = $_POST['email'];
$password_1 = $_POST['password'];

// //3.1.2 Checking the values are existing in the database or not
$sql = "SELECT * FROM `Customers` WHERE email='$username' and password='$password_1'";

$result = $conn->query($sql);
$rows=$result->fetch_assoc();
if ($rows['email']==$username && $rows['password']==$password_1){
  header('Location: '."./amin.php");
}
else{
  echo "Credentials are not correct! <br>";
  echo "<a href = './login.html'>Try again</a>";
}

}


?>