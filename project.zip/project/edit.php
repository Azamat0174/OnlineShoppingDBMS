
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Document</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #90b7d3;">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="admin.png" alt="" width="35" height="30" class="d-inline-block align-text-top">
                Edit Record
            </a>
        </div>
    </nav>
<div class="container">


<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Online Shopping";
$update=true;
$id = $_POST['pk'];
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM `Product` WHERE ID='$id'";

$result = $conn->query($sql);
$rows = $result->fetch_assoc();
$name = $rows['product_name'];
$price = $rows['price'];
$quantity = $rows['quantity'];
$description = $rows['description'];
$images = $rows['images'];




?>
                <form class="row g-3" method="post" action="./update.php" enctype="multipart/form-data">
                    <div class="col-md-12">
                      <label for="inputEmail4" class="form-label">Product Name</label>
                      <input type="text" name="product_name" value='<?php echo $name ?>' class="form-control" id="inputEmail4">
                    </div>
                    <div class="col-md-12">
                      <label for="inputPassword4" class="form-label">Price</label>
                      <input type="number" name="price" class="form-control" value='<?php echo $price ?>' id="inputPassword4">
                    </div>

                    <div class="col-12">
                      <label for="inputAddress" class="form-label">Quantity</label>
                      <input type="text" name="quantity"  value='<?php echo $quantity ?>' class="form-control" id="inputAddress">
                    </div>

                    <div class="col-12">
                      <label for="description" class="form-label">Description</label>
                      <textarea class="form-control"  name="description" id="description" cols="30" rows="10"><?php echo $description ?></textarea>
                    </div>



                    <div class="col-md-12">
                      <label for="inputCity" class="form-label">Upload Image</label>
                      <input type="file" name="images"  class="form-control" id="inputCity" >
                    </div>
                    <input type="hidden" value='<?php echo $images ?>' name="img" id="">
                    <input type="hidden" name="pk" value='<?php echo $id ?>' id="">

                    <div class="col-12">
                      <button type="submit" class="btn btn-primary" name="update">Update</button>
                    </div>
                  </form>


                  </div>

            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
        crossorigin="anonymous"></script>

</body>

</html>
