
<?php
$images = "";
if (isset($_FILES['images'])) {

    $errors = array();
    $file_name = $_FILES['images']['name'];
    $file_size = $_FILES['images']['size'];
    $file_tmp = $_FILES['images']['tmp_name'];
    $file_type = $_FILES['images']['type'];
    $file_ext = strtolower(end(explode('.', $_FILES['images']['name'])));


   

   

    if (empty($errors) == true) {
        move_uploaded_file($file_tmp, "" . $file_name);
        echo "Success";
    } else {
        print_r($errors);
    }}

$name = $_POST['product_name'];
$price = $_POST["price"];
$quantity = $_POST['quantity'];
$description = $_POST['description'];
$images = $file_name;
$id = $_POST['pk'];

if($images==''){
    $images=$_POST['img'];

}



$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Online Shopping";
$update = true;
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



$s = "UPDATE Product SET product_name='$name', price='$price',quantity='$quantity',description='$description', images='$images' WHERE ID='$id' ";

if (mysqli_query($conn, $s)) {
    header('Location:' . './amin.php');
} else {
    echo "Error updating record: " . mysqli_error($conn);
}

mysqli_close($conn);

$conn->close();

?>