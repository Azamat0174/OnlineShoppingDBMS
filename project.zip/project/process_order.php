<?php
$name = $_POST['p_name'];
$id = $_POST['p_id'];
$full_name = $_POST['full_name'];

$phone = $_POST['phone'];
$address = $_POST['address'];
$quantity = $_POST['quantity'];
$total_price = $_POST['total_price'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Online Shopping";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO Orders (customer_name, product, phone, address,details,quantity)
VALUES ('$full_name','$name','$phone', '$address','$total_price','$quantity')";

if ($conn->query($sql) === true) {
    
    header('Location: '."./index.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Update product table
$connection = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

$sq = "SELECT quantity FROM `Product` WHERE ID='$id' ";

$result = $connection->query($sq);
$rows = $result->fetch_assoc();
$q = $rows['quantity'];
$re=$q - $quantity;
if ($re < 0) {
    echo "No product left";

} else {
    $s = "UPDATE Product SET quantity='$re' WHERE ID='$id' ";

    if (mysqli_query($connection, $s)) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . mysqli_error($connection);
    }

    mysqli_close($connection);

    $connection->close();

}
?>
