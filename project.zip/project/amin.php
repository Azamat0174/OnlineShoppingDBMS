<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Document</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #90b7d3;">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="admin.png" alt="" width="35" height="30" class="d-inline-block align-text-top">
                Admin Panel
            </a>
        </div>
    </nav>


    <div class="d-flex align-items-start">
        <div class="nav flex-column nav-pills me-3" id="v-pills-tab" role="tablist" aria-orientation="vertical">
            <button class="nav-link active" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-home"
                type="button" role="tab" aria-controls="v-pills-home" aria-selected="true">Dashboard</button>
            <button class="nav-link" id="v-pills-messages-tab" data-bs-toggle="pill" data-bs-target="#v-pills-messages"
                type="button" role="tab" aria-controls="v-pills-messages" aria-selected="false">Orders</button>
            <button class="nav-link" id="v-pills-settings-tab" data-bs-toggle="pill" data-bs-target="#v-pills-settings"
                type="button" role="tab" aria-controls="v-pills-settings" aria-selected="false">Add Product</button>
            <button class="nav-link" id="v-pills-productlist-tab" data-bs-toggle="pill"
                data-bs-target="#v-pills-productlist" type="button" role="tab" aria-controls="v-pills-productlist"
                aria-selected="false">Product List</button>
            <button class="nav-link" id="v-pills-logout-tab" data-bs-toggle="pill" data-bs-target="#v-pills-logout"
                type="button" role="tab" aria-controls="v-pills-logout" aria-selected="false">Logout</button>

        </div>
<!-- Dashboard -->
        <div class="tab-content" id="v-pills-tabContent">
            <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                <table class="table caption-top">
                    <caption>List</caption>
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Customers</th>

                            <th scope="col">Total Number of Product</th>
                            <th scope="col">Total Price</th>
                            <th scope="col">Sold</th>

                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th scope="row">1</th>
                        </tr>
                    </tbody>
                </table>



            </div>
           
            <!-- Orders Table -->
            <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                <table class="table caption-top">
                    <caption>List of Orders</caption>
                    <thead>

                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Customers Name</th>

                            <th scope="col">Products</th>
                            <th scope="col">Contact | Phone</th>
                            <th scope="col">Address</th>
                            <th scope="col">Price</th>
                            <th scope="col">Quantity</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Online Shopping";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM Orders";
$result = $conn->query($sql);
$conn->close();

?>
                          <?php // LOOP TILL END OF DATA
while ($rows = $result->fetch_assoc()) {
    ?>

                       <tr>
                         <td><?php echo $rows['ID']; ?></td>
                         <td><?php echo $rows['customer_name']; ?></td>
                         <td><?php echo $rows['product']; ?></td>
                         <td><?php echo $rows['phone']; ?></td>
                         <td><?php echo $rows['address']; ?></td>
                         <td><?php echo $rows['details']; ?></td>
                         <td><?php echo $rows['quantity']; ?></td>


                       
                        </tr>
                       
                       <?php
}
?>

                    </tbody>
                </table>

                <!-- Add new product -->
            </div>
            <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                <form class="row g-3" method="post" action="./addproduct.php" enctype="multipart/form-data">
                    <div class="col-md-12">
                      <label for="inputEmail4" class="form-label">Product Name</label>
                      <input type="text" name="product_name" class="form-control" id="inputEmail4">
                    </div>
                    <div class="col-md-12">
                      <label for="inputPassword4" class="form-label">Price</label>
                      <input type="number" name="price" class="form-control" id="inputPassword4">
                    </div>

                    <div class="col-12">
                      <label for="inputAddress" class="form-label">Quantity</label>
                      <input type="text" name="quantity"  class="form-control" id="inputAddress">
                    </div>

                    <div class="col-12">
                      <label for="description" class="form-label">Description</label>
                      <textarea class="form-control" name="description" id="description" cols="30" rows="10"></textarea>
                    </div>



                    <div class="col-md-12">
                      <label for="inputCity" class="form-label">Upload Image</label>
                      <input type="file" name="images" class="form-control" id="inputCity" >
                    </div>

                    <div class="col-12">
                      <button type="submit" class="btn btn-primary" name="uploadfile">Add</button>
                    </div>
                  </form>

            </div>
            <!-- Product List -->
            <div class="tab-pane fade" id="v-pills-productlist" role="tabpanel"
                aria-labelledby="v-pills-productlist-tab">
                <table class="table">
                    <thead>
                       <tr>
                         <th scope="col">ID</th>
                         <th scope="col">Product Name</th>
                         <th scope="col">Price</th>
                         <th scope="col">Quantity</th>
                         <th scope="col">Edit</th>
                         <th scope="col">Delete</th>
                         
                       </tr>
                       
                     </thead>
                     <tbody>
                         <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Online Shopping";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM Product";
$result = $conn->query($sql);
$conn->close();

?>
                          <?php // LOOP TILL END OF DATA
while ($rows = $result->fetch_assoc()) {
    ?>

                       <tr>
                         <td><?php echo $rows['ID']; ?></td>
                         <td><?php echo $rows['product_name']; ?></td>
                         <td><?php echo $rows['price']; ?></td>
                         <td><?php echo $rows['quantity']; ?></td>

                         <td>
                             <form action="./edit.php" method="POST" >
                                 <input type="hidden" name="pk" value='<?php echo $rows['ID']; ?>'>
                                 <input type="submit" class="btn btn-success btn-sm" value="edit" >
                                 
                             </form>

                         </td>
                         <td>
                             <form action="./delete.php" method="POST">
                                 <input type="hidden" name="pk1" value='<?php echo $rows['ID']; ?>'>
                                 <input type="submit" class="btn btn-danger btn-sm" value="delete" >
                             </form>
                         </td>


                       </tr>
                       <?php
}
?>
                     </tbody>
                </table>




            </div>
            <div class="tab-pane fade" id="v-pills-logout" role="tabpanel" aria-labelledby="v-pills-logout-tab"></div>


        </div>
    </div>










    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
        crossorigin="anonymous"></script>

</body>

</html>