<?php
$name = $_POST['name'];
$email = $_POST["email"];
$phone=$_POST['phone'];
$password1=$_POST['password'];


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Online Shopping";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO Customers (full_name, phone, email, password)
VALUES ('$name','$phone','$email','$password1')";

if ($conn->query($sql) === TRUE) {
    header('Location: '."./index.php");
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close(); 




?>