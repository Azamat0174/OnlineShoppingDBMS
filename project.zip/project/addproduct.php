<?php
$images ="";
if(isset($_FILES['images'])){

  $errors= array();
  $file_name = $_FILES['images']['name'];
  $file_size =$_FILES['images']['size'];
  $file_tmp =$_FILES['images']['tmp_name'];
  $file_type=$_FILES['images']['type'];
  $file_ext=strtolower(end(explode('.',$_FILES['images']['name'])));
  
  $extensions= array("jpeg","jpg","png");
  
  if(in_array($file_ext,$extensions)=== false){
      $errors[]="extension not allowed, please choose a JPEG or PNG file.";
  }
  
  if($file_size > 2097152){
      $errors[]='File size must be excately 2 MB';
  }
  
  if(empty($errors)==true){
      move_uploaded_file($file_tmp,"".$file_name);
      echo "Success";
  }else{
      print_r($errors);
  }




}

  $name = $_POST['product_name'];
$price = $_POST["price"];
$quantity=$_POST['quantity'];
$description=$_POST['description'];
$images = $file_name;




$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Online Shopping";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO Product (product_name, price, quantity, description,images)
VALUES ('$name','$price','$quantity', '$description','$images')";

if ($conn->query($sql) === TRUE) {
  header('Location:'.'./amin.php' );
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();




?>

